//  Writing a program in Java to verify implementations of regular expressions
import java.util.regex.Pattern;
 

class Expressions {
 
    // Main driver method
    public static void main(String args[])
    {
 
        System.out.println(Pattern.matches(
            "geeksforge*ks", "geeksforgeeks"));                               // checking the patter whether it is matching or not
 
        System.out.println(
            Pattern.matches("g*geeks*", "geeksfor"));
    }
}
