package com;

import java.util.Arrays;

public class BinarySearch {
   public static int BinarySearch(int arr[], int l,int r, int x) {
	   if(r>=l) {
	   int mid=l+(r-l)/2;
	   
	   if(arr[mid]==x) {
		   return mid;
	   }
	   
	   if((arr[mid])<x) {
		   return BinarySearch(arr, mid+1,r,x);
	   }
	   else {
		   return BinarySearch(arr,l,mid-1,x);
	   }
   }
	   return -1;
   }
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String args[]) {
		// int arr[]= {2,8,9,6,7,5,4,3,1};
		int x=7;
		// Arrays.sort(arr);
		 int arr[]= {1,2,3,4,5,6,7,8,9};
		int result= BinarySearch(arr, 0, arr.length-1,x);
		System.out.println("the particular index is"+result);
	}
}
