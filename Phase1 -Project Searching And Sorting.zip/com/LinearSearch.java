package com;

import java.util.Scanner;

public class LinearSearch {
 
	public static int LinearSearch(int input, int arr[]) {
		int flag=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==input) {
				flag=1;
				break;
			}
		}
		if(flag==1) {
			return 1;
		}
		else {
			return 0;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int arr[]= {2,5,6,3,9,8};
		int input=sc.nextInt();
		if(LinearSearch(input,arr)==1) {
			System.out.println("we have found the element");
		}
		else {
			System.out.println("The element is not found");
		}
	}
}
