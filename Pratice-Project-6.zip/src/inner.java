// Writing a program in Java to verify the implementation of inner classe

class Outer {
 
    
    class Inner {
 
        // show() method of inner class
        public void show()
        {
 
            // Print statement
            System.out.println("In a nested class method");
        }
    }
}
class inner {
 
    // Main driver method
    public static void main(String[] args)
    {
 
        // Note how inner class object is created inside
        // main()
        Outer.Inner in = new Outer().new Inner();
 
        // Calling show() method over above object created
        in.show();
    }
}
