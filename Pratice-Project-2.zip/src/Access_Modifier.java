// Writing a program in Java to implement access modifiers

	class A
	{
	private void display()
	    {
	        System.out.println("GeeksforGeeks");
	    }
	}
	                                                                            //  private
	class B
	{
	public static void main(String args[])
	    {
	        A obj = new A();
	        // Trying to access private method
	        // of another class
	        obj.display();
	    }
	}


	public class A
	{
	protected void display()
	    {
	        System.out.println("GeeksforGeeks");
	    }                                                                         //Protected
	}
	
	class B extends A
	{
	public static void main(String args[])
	{
	    B obj = new B();
	    obj.display();
	}
	     
	}
	
	
	public class A
	{
	public void display()
	    {
	        System.out.println("GeeksforGeeks");
	    }
	}
	                                                                // public
	class B {
	    public static void main(String args[])
	    {
	        A obj = new A();
	        obj.display();
	    }
	}