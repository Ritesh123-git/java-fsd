// Writing a program in Java to implement implicit and explicit type casting
class Explicit_Implicit{
public static void main(String args[]){
 double d = 100.04;   // explicit type conversion
 long l=(long)d;      // explicit type conversion
int i=(int)l;
 System.out.println("double value is" +d);
System.out.println("long value is" +l);
System.out.println("int value is" +i);

int p=10;
float a=p;               // implicit type conversion
double r=a;              // implicit type conversion
System.out.println("int value is" +p);
System.out.println("float value is" +a);
System.out.println("double value is" +r);
}
}
