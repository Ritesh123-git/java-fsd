// Writing a program in Java to verify implementations of methods and ways of calling a method  
public class Method_1 {
	void display(){
  	  System.out.println("Method implementing");
    }
	public static void main(String args[]) {
      Method_1 obj = new Method_1();
      obj.display();
      
      
      
      
      
}
}
