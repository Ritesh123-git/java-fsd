// Writing a program in Java to verify implementation of arrays


public class Array_Implementation {
	public static void main(String args[]) {
   int arr[]= new int[3];   
   // initializing the array and assigning it the size;
   arr[0]=1;
   arr[1]=2;
   arr[2]=3;
   //  providing the element to the array
   
   
   // Now printing the element of the array
   
   for(int i=0;i<arr.length;i++) {System.out.println(arr[i]);
   }
   }
}
