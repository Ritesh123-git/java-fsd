//  Write a program to create strings and display the conversion of string to StringBuffer and StringBuilder.
public class Conversion_String {
public static void main(String args[]) {
	String project="hii";
	 StringBuilder s2 = new StringBuilder(project);
	 StringBuffer s3 = new StringBuffer(project);
}
}
